# Dutch Speech-to-Text and Grammar Correction App

## Overview

This is a Streamlit app that allows users to record audio or upload audio files, transcribes the audio to Dutch text, and then corrects the grammar and spelling of the transcribed text using the OpenAI API.

## Features

- **Audio Recording:** Users can record audio directly within the app.
- **Audio File Upload:** Users can upload pre-recorded audio files for transcription.
- **Speech-to-Text:** The app transcribes Dutch audio to text using the Wav2Vec2 model.
- **Grammar and Spelling Correction:** The transcribed text is corrected for grammar and spelling errors using the OpenAI API.

## Installation

To run this app locally, you need to have Python installed on your system. Follow these steps to set up the app:

1. Install the required dependencies:
   ```bash
   pip install -r requirements.txt

2. Run the app:
   ```bash
   streamlit run app.py


## Usage
- Recording Audio: Click the "Record" button to start recording and "Stop" to end the recording. The - recorded audio will be automatically processed.
- Uploading Audio Files: Click the "Browse files" button to upload an audio file. The file will be - automatically processed once uploaded.
- Viewing Results: The transcribed text will be displayed under "Transcribed Text," and the corrected text will be displayed under "Corrected Transcription."
