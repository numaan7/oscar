## Importing the Libraries
import streamlit as st
import openai
import torch
from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor
import torchaudio
from st_audiorec import st_audiorec
import os
import torchaudio.transforms as T

# OpenAI API key setup
openai.api_key = "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"

# Load the model and processor for Dutch language transcription (only once when the app starts)
@st.cache_resource
def load_model():
    processor = Wav2Vec2Processor.from_pretrained("jonatasgrosman/wav2vec2-xls-r-1b-dutch")
    model = Wav2Vec2ForCTC.from_pretrained("jonatasgrosman/wav2vec2-xls-r-1b-dutch")
    return processor, model

processor, model = load_model()

# Function to transcribe audio
def transcribe_audio(audio_file_path):
    """Transcribes the audio file at the given path to text."""
    # Load the audio file
    speech, sample_rate = torchaudio.load(audio_file_path)

    # Convert to mono if necessary
    if speech.shape[0] > 1:
        speech = torch.mean(speech, dim=0, keepdim=True)

    # Resample the audio to 16 kHz if necessary
    if sample_rate != 16000:
        resampler = T.Resample(orig_freq=sample_rate, new_freq=16000)
        speech = resampler(speech)

    # Process the speech audio for transcription
    input_values = processor(speech, return_tensors="pt", padding=True, sampling_rate=16000).input_values
    input_values = input_values.squeeze(1)  # Squeeze the extra dimension

    # Get logits from the model
    with torch.no_grad():
        logits = model(input_values).logits

    # Decode the logits to text
    predicted_ids = torch.argmax(logits, dim=-1)
    transcription = processor.batch_decode(predicted_ids)[0]
    return transcription

# Function to correct text using GPT
def correct_text_with_gpt(text):
    """Corrects the given text for grammar and spelling using GPT."""
    # Split text into sentences
    sentences = text.split(". ")
    corrected_sentences = []

    for sentence in sentences:
        # Generate prompt for correction
        prompt = f"Correct the following Dutch text for grammar and spelling:\n\n{sentence}"
        response = openai.completions.create(
            model="gpt-3.5-turbo",
            prompt=prompt,
            temperature=0,
            max_tokens=100,
            top_p=1.0,
            frequency_penalty=0.0,
            presence_penalty=0.0
        )
        corrected = response.choices[0].text.strip()
        corrected_sentences.append(corrected)

    # Reassemble the corrected text
    corrected_text = ". ".join(corrected_sentences)
    return corrected_text

# Streamlit app UI
st.title("✨Dutch Speech-to-Text and Grammar Correction App🔊")

# Record audio using the st_audiorec component
wav_audio_data = st_audiorec()

if wav_audio_data is not None:
    # Save the recorded audio to a file in the current directory
    file_path = os.path.join(os.getcwd(), "recorded_audio.mp3")
    with open(file_path, "wb") as f:
        f.write(wav_audio_data)

    # Transcribe the audio
    transcription = transcribe_audio(file_path)
    st.balloons()
    st.text_area("Transcribed Text:", transcription, height=150)

    # Correct the transcription
    corrected_transcription = correct_text_with_gpt(transcription)
    st.text_area("Corrected Transcription:", corrected_transcription, height=150)
